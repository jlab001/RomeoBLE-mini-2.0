/*Romeo BLE mini���ļ�

  �汾��1.0

  board:Romeo BLE mini

  ��˾���ɶ���Ȥ�Ƽ����޹�˾

  ��վ��http://dfrobot.com.cn

  Modified for Romeo BLE mini V2.0 (20180102)

*/





#include "Arduino.h"
#include "Romeo_m.h"
int E1 = 5;     //M1 Speed Control
int E2 = 6;     //M2 Speed Control
int M1 = 4;    //M1 Direction Control
int M2 = 7;    //M1 Direction Control



void Romeo_mClass::Initialise()
{
	   pinMode(4, OUTPUT);
     pinMode(5, OUTPUT);
     pinMode(6, OUTPUT);
     pinMode(7, OUTPUT);
}
void Romeo_mClass::motorControl(int M1Dir,int a,int M2Dir,int b)
{
if((M1Dir == 0) && (M2Dir==0))
{
  analogWrite (E1,a);      //PWM Speed Control
  digitalWrite(M1,HIGH);    
  analogWrite (E2,b);    
  digitalWrite(M2,HIGH);
}

if((M1Dir == 1) && (M2Dir==1))
{
  analogWrite (E1,a);
  digitalWrite(M1,LOW);   
  analogWrite (E2,b);    
  digitalWrite(M2,LOW);
}

if((M1Dir == 0) && (M2Dir==1))
{
  analogWrite (E1,a);
  digitalWrite(M1,LOW);    
  analogWrite (E2,b);    
  digitalWrite(M2,HIGH);
}

if((M1Dir == 1) && (M2Dir==0))
{
  analogWrite (E1,a);
  digitalWrite(M1,HIGH);    
  analogWrite (E2,b);    
  digitalWrite(M2,LOW);
}



}

	void Romeo_mClass::motorStop()
	{

     digitalWrite(5,0);  
     digitalWrite(6,0);  

	}
	
				 
		 

Romeo_mClass Romeo_m;